# Nedu Blockchain

Nedu ist eine browserbasierte Lern-Blockchain mit fairer Mining-Logik, Seed-basierten Wallets und validierter Blockchainstruktur.  
Ziel: Blockchain selbst erleben, Coins verdienen und die Kette öffentlich validieren lassen.

## Bestandteile
- `wallet.html`: Seed-Wallet mit Adressanzeige, Coinstand und Senden
- `miner.html`: Browser-Miner mit Blockbelohnung und Blockchain-Speicherung
- `upload.html`: GitHub-Upload deiner `blocks.json` mit Token
- `validator.js`: Prüfung der Blockchain (CLI, Node.js)
